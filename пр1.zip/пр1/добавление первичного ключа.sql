ALTER TABLE `оснащение_компьютерных_лабораторий`
ADD PRIMARY KEY (`id_лаборатории`);