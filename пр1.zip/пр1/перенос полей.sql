ALTER TABLE `аудитории`
ADD COLUMN `длина_аудитории` DECIMAL(5,2);
ALTER TABLE `аудитории`
ADD COLUMN `ширина_аудитории` DECIMAL(5,2);
ALTER TABLE `аудитории`
ADD COLUMN `площадь_аудитории` DECIMAL(10,2);
ALTER TABLE `компьютеры`
ADD COLUMN `стоимость_компьютера` DECIMAL(10,2);

ALTER TABLE `лаборатории`
DROP COLUMN `длина_аудитории`;
ALTER TABLE `лаборатории`
DROP COLUMN `ширина_аудитории`;
ALTER TABLE `лаборатории`
DROP COLUMN `площадь_аудитории`;
ALTER TABLE `лаборатории`
DROP COLUMN `стоимость_компьютера`;