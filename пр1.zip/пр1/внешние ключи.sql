ALTER TABLE `лаборатории`
ADD FOREIGN KEY (`номер_аудитории`)
REFERENCES `аудитории` (`номер_аудитории`);

ALTER TABLE `лаборатории`
ADD COLUMN `id_модели` INT;
ALTER TABLE `лаборатории`
ADD FOREIGN KEY (`id_модели`)
REFERENCES `компьютеры` (`id_модели`);