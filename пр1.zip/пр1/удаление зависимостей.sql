CREATE TABLE `аудитории` (
    `номер_аудитории` INT PRIMARY KEY
);

CREATE TABLE `компьютеры` (
    `id_модели` INT PRIMARY KEY,
    `название_модели` VARCHAR(100)
);