ALTER TABLE `оснащение_компьютерных_лабораторий`
ADD COLUMN `фамилия_директора` VARCHAR(30);
ALTER TABLE `оснащение_компьютерных_лабораторий`
ADD COLUMN `имя_директора` VARCHAR(30);
ALTER TABLE `оснащение_компьютерных_лабораторий`
ADD COLUMN `отчество_директора` VARCHAR(30);