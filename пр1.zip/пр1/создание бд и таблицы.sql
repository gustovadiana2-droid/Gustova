create database hotel;
use hotel;
create table гостиница (
фамилия_ИО_жильца varchar(100) not null,
номер_проживания int not null,
классность_номера int not null,
стоимость_проживания_одних_суток decimal(10, 2) not null,
дата_бронирования date,
дата_начала_проживания date not null,
дата_освобождения_номера date not null,
стоимость_проживания_в_гостинице decimal(10, 2) not null
);

alter table гостиница
add primary key (фамилия_ИО_жильца, номер_проживания);

create table жильцы (
id_жильца int auto_increment not null primary key,
фамилия_ИО_жильца varchar(100) not null
);

create table номера (
номер_проживания int not null primary key,
классность_номера int not null,
стоимость_проживания_одних_суток decimal(10, 2) not null
);

create table проживание (
id_проживания int auto_increment not null primary key,
id_жильца int not null,
номер_проживания int not null,
дата_бронирования date,
дата_начала_проживания date not null,
дата_освобождения_номера date not null,
стоимость_проживания_в_гостинице decimal(10, 2) not null,
foreign key (id_жильца) references жильцы (id_жильца),
foreign key (номер_проживания) references номера (номер_проживания)
);

drop table гостиница;

alter table жильцы drop column фамилия_ИО_жильца,
add column фамилия_жильца varchar(30) not null,
add column имя_жильца varchar(30) not null,
add column отчество_жильца varchar(30);

create table классы_номеров (
    классность_номера int not null primary key,
    стандартная_стоимость_за_сутки decimal(10, 2) not null
);

alter table номера
drop column стоимость_проживания_одних_суток,
add foreign key (классность_номера) references классы_номеров(классность_номера);

alter table жильцы 
add column дата_рождения date not null,
add column телефон varchar(11) not null,
add column email varchar(100);

alter table номера
add column этаж int not null,
add column вместимость int not null;